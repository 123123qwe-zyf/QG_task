#include <REGX52.H>
#include <intrins.h>


sbit I2C_SCL=P2^1;
sbit I2C_SDA=P2^0;

// ΢�뼶����ʱ
void I2C_Delay()
{
    _nop_();_nop_();_nop_();_nop_();
}

void I2C_Start(void)
{
	I2C_SDA=1;
	I2C_SCL=1;
	I2C_Delay();
	I2C_SDA=0;
	I2C_Delay();
	I2C_SCL=0;
}

void I2C_Stop(void)
{
	I2C_SDA=0;
	I2C_SCL=1;
  I2C_Delay();
	I2C_SDA=1;
  I2C_Delay();
}

void I2C_SendByte(unsigned char Byte)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		I2C_SDA=Byte&(0x80>>i);
		I2C_Delay();
		I2C_SCL=1;
		I2C_Delay();
		I2C_SCL=0;
	}
}
unsigned char I2C_Receivebyte(void)
{
	unsigned char i,byte=0x00;
	for(i=0;i<8;i++)
	{
		I2C_SCL=1;
		I2C_Delay();
		if(I2C_SDA)
		{
			byte|=(0x80>>i);
		}
		I2C_SCL=0;
		I2C_Delay();
	}
	return byte;
}
//i2c����Ӧ��
//0Ӧ��  1��Ӧ��
void I2C_SendAck(unsigned char ackbit)
{
	I2C_SDA=ackbit;
	I2C_Delay();
	I2C_SCL=1;
	I2C_Delay();
	I2C_SCL=0;
}

//i2c����Ӧ��λ
unsigned char I2C_ReceiveAck(void)
{
	unsigned char ackbit;
	I2C_SDA=1;
	I2C_Delay();
	I2C_SCL=1;
	I2C_Delay();
	ackbit=I2C_SDA;
	I2C_SCL=0;
	return ackbit;
}	
