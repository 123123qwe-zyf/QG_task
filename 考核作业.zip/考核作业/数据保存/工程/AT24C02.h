#ifndef __AT24C02_H__
#define __AT24C02_H__

void AT24C02_WriteByte(unsigned char wordAddress,unsigned char Data);
unsigned char AT24C02_ReadByte(unsigned char WordAddress);
void AT24C02_write_multi(unsigned char addr,unsigned char *buf,unsigned char len);
void AT24C02_read_multi(unsigned char addr,unsigned char *buf,unsigned char len);

#endif

