#include <REGX52.H>
#include "UART.h"
#include "AT24C02.h"

#define EEPROM_ADDR 0x00  //�洢��ʼ��ַ
#define MAX_LEN 4  //������


void Delay(unsigned int xms)		//@11.0592MHz
{
	unsigned int i, j;

	while(xms--)
	{
		i = 2;
		j = 199;
		do
		{
			while (--j);
		} while (--i);
	}
}


unsigned char uart_buf[MAX_LEN]={0};
unsigned char uart_cnt=0;
bit save_flag=0;

void UART_IRQ() interrupt 4
{
	if(RI)
	{
		RI=0;
		uart_buf[uart_cnt++]=SBUF;
		if(uart_cnt>=MAX_LEN)
		{
			uart_cnt=0;
			save_flag=1;
		}
	}
}

void main(void)
{
	unsigned char read_buf[MAX_LEN];
	unsigned char i;
	UART_Init();
	
	EA=1;
	ES=1;
	
	AT24C02_read_multi(EEPROM_ADDR,read_buf,MAX_LEN);
	UART_SendString("power on! read :");
	
	for(i=0;i<MAX_LEN;i++)
	{
		UART_SendHex(read_buf[i]);
		UART_SendString(" ");
	}
	UART_SendString("\r\n");
	
	while(1)
	{
		if(save_flag==1)
		{
			save_flag=0;
			for(i=0; i<MAX_LEN; i++) read_buf[i] = 0;//�������������
			AT24C02_write_multi(EEPROM_ADDR,uart_buf,MAX_LEN);
			Delay(10);//�ȴ�����д��оƬ
			AT24C02_read_multi(EEPROM_ADDR,read_buf,MAX_LEN);			
			UART_SendString("save done!\r\n");
			for(i=0; i<MAX_LEN; i++)
      {
				 UART_SendHex(read_buf[i]);
				 UART_SendString(" ");
      }
      UART_SendString("\r\n");
		}
	}
}
