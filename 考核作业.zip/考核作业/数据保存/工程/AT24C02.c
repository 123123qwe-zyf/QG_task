#include <REGX52.H>
#include "I2C.h"

#define AT24C02_ADDRESS 0xA0  //I2CѰַ��
void Delay(unsigned int xms);

/**
  * @brief  AT24C02д��һ���ֽ�
  * @param  WordAddress Ҫд���ֽڵĵ�ַ
  * @param  Data Ҫд�������
  * @retval ��
  */
void AT24C02_WriteByte(unsigned char wordAddress,unsigned char Data)
{
	I2C_Start();
	I2C_SendByte(AT24C02_ADDRESS);
	I2C_ReceiveAck();
	I2C_SendByte(wordAddress);
	I2C_ReceiveAck();
	I2C_SendByte(Data);
	I2C_ReceiveAck();
	I2C_Stop();
	Delay(5);
}
/**
  * @brief  AT24C02��ȡһ���ֽ�
  * @param  WordAddress Ҫ�����ֽڵĵ�ַ
  * @retval ����������
  */
unsigned char AT24C02_ReadByte(unsigned char WordAddress)
{

	unsigned char Data;
	I2C_Start();
  I2C_SendByte(AT24C02_ADDRESS);
	I2C_ReceiveAck();
	I2C_SendByte(WordAddress);
	I2C_ReceiveAck();
	I2C_Start();
  I2C_SendByte(AT24C02_ADDRESS|0x01);
	I2C_ReceiveAck();
	Data=I2C_Receivebyte();
	I2C_SendAck(1);
	I2C_Stop();
	return Data;
}
//д�������
void AT24C02_write_multi(unsigned char addr,unsigned char *buf,unsigned char len)
{
	unsigned char i;
	for(i=0;i<len;i++)
	{
		AT24C02_WriteByte(addr+i,buf[i]);
	}
}

void AT24C02_read_multi(unsigned char addr,unsigned char *buf,unsigned char len)
{
	unsigned char i;
	for(i=0;i<len;i++)
	{
		buf[i]=AT24C02_ReadByte(addr+i);
	}
}