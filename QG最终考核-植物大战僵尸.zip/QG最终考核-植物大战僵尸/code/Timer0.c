#include <reg52.h>
#include "timer0.h"

volatile unsigned int idata game_time = 0;

void Timer0Init(void)
{
	TMOD &= 0xF0;
	TMOD |= 0x01;
	TL0 = 0x18;
	TH0 = 0xFC;
	TF0 = 0;
	TR0 = 1;
	ET0 = 1;
	PT0 = 0;
}

void Timer0_ISR(void) interrupt 1
{
	TL0 = 0x18;
	TH0 = 0xFC;
	game_time++;
}