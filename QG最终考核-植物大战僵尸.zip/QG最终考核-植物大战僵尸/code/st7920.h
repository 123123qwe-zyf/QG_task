#ifndef ST7920_H
#define ST7920_H

#include <reg52.h>

sbit LCD_RS  = P3^4;
sbit LCD_RW  = P3^5;
sbit LCD_E   = P3^3;
sbit LCD_RST = P3^2;

void delay_ms(unsigned int ms);
void LCD_write_cmd(unsigned char cmd);
void LCD_write_dat(unsigned char dat);
void LCD_init(void);
void LCD_clear(void);

#endif