#include <reg52.h>
#include "keys.h"

sbit k_confirm = P2^1;
sbit k_down    = P2^2;
sbit k_right   = P2^3;
sbit k_pause   = P2^4;
sbit k_nut     = P2^5;
sbit k_sun     = P2^6;
sbit k_shoot   = P2^7;

static unsigned char flag_confirm = 0;
static unsigned char flag_down    = 0;
static unsigned char flag_right   = 0;
static unsigned char flag_pause   = 0;
static unsigned char flag_nut     = 0;
static unsigned char flag_sun     = 0;
static unsigned char flag_shoot   = 0;

void keys_init(void)
{
    P2 |= 0xFF;
    flag_confirm = 0;
    flag_down    = 0;
    flag_right   = 0;
    flag_pause   = 0;
    flag_nut     = 0;
    flag_sun     = 0;
    flag_shoot   = 0;
}

void keys_scan(void)
{
    if(k_confirm == 0) flag_confirm = 1;
    if(k_down    == 0) flag_down    = 1;
    if(k_right   == 0) flag_right   = 1;
    if(k_pause   == 0) flag_pause   = 1;
    if(k_nut     == 0) flag_nut     = 1;
    if(k_sun     == 0) flag_sun     = 1;
    if(k_shoot   == 0) flag_shoot   = 1;
}

unsigned char key_confirm(void) { unsigned char t = flag_confirm; flag_confirm = 0; return t; }
unsigned char key_down(void)    { unsigned char t = flag_down;    flag_down    = 0; return t; }
unsigned char key_right(void)   { unsigned char t = flag_right;   flag_right   = 0; return t; }
unsigned char key_pause(void)    { unsigned char t = flag_pause;   flag_pause   = 0; return t; }
unsigned char key_nut(void)      { unsigned char t = flag_nut;     flag_nut     = 0; return t; }
unsigned char key_sun(void)      { unsigned char t = flag_sun;     flag_sun     = 0; return t; }
unsigned char key_shoot(void)    { unsigned char t = flag_shoot;   flag_shoot   = 0; return t; }

void keys_clear(void)
{
    flag_confirm = 0;
    flag_down    = 0;
    flag_right   = 0;
    flag_pause   = 0;
    flag_nut     = 0;
    flag_sun     = 0;
    flag_shoot   = 0;
}