#include <reg52.h>

#ifndef GAME_H
#define GAME_H

sbit buzzer=P3^7;
void game_start(unsigned char hard);

#endif