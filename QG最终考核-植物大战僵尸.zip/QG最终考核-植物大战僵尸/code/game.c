#include <reg52.h>
#include "lcd_text.h"
#include "Delay.h"
#include "keys.h"
#include "game.h"
#include "timer0.h"

#define ROWS     3
#define COLS    16
#define HUD_ROW  0
#define MAP_ROW  1

#define EMPTY    0
#define SUN      1
#define NUT      2
#define SHOOT    3

#define Z_NUM    5
#define B_NUM    4

#define Z1_HP_E  40
#define Z1_HP_H  50
#define Z2_HP_E  70
#define Z2_HP_H  80

static unsigned char idata map[ROWS][COLS];
static unsigned char idata hp[ROWS][COLS];

typedef struct {
    unsigned char row;
    unsigned char col;
    unsigned char hp;
    unsigned char type;
} Zombie;

typedef struct {
    unsigned char row;
    unsigned char col;
    unsigned char active;
} Bullet;

static Zombie idata zombies[Z_NUM];
static Bullet idata bullets[B_NUM];

static unsigned char idata sun;
static unsigned char idata cur_r;
static unsigned char idata cur_c;
static unsigned char idata wave;
static unsigned int  idata last_move;
static unsigned int  idata last_spawn;
static unsigned int  idata last_sun;
static unsigned int  idata last_bul;
static bit is_pause;
static bit is_fail;
static bit is_hard;

static unsigned char random_row(void)
{
    return (game_time ^ (game_time >> 3)) % 3;
}

static void game_reset(void)
{
    unsigned char r, c, i;
    
    for(r = 0; r < ROWS; r++)
        for(c = 0; c < COLS; c++)
        {
            map[r][c] = 0;
            hp[r][c] = 0;
        }
    
    for(i = 0; i < Z_NUM; i++)
        zombies[i].hp = 0;
    
    for(i = 0; i < B_NUM; i++)
        bullets[i].active = 0;
    
    sun = is_hard ? 35 : 50;
    cur_r = 0;
    cur_c = 0;
    wave = (3 << 2) | 2;
    last_move = game_time;
    last_spawn = game_time;
    last_sun = game_time;
    last_bul = game_time;
    is_pause = 0;
    is_fail = 0;
}

static void draw_top(void)
{
    unsigned char s = sun;
    if(s > 99) s = 99;
    
    lcd_show_string(HUD_ROW, 0, "Sun:");
    lcd_show_number(HUD_ROW, 4, s);
    lcd_show_string(HUD_ROW, 6, "        ");
    lcd_show_char(HUD_ROW, 14, is_pause ? 'P' : ' ');
    lcd_show_char(HUD_ROW, 15, is_pause ? '!' : ' ');
    lcd_refresh_row(HUD_ROW);
}

static unsigned char has_zombie(unsigned char r, unsigned char c)
{
    unsigned char i;
    for(i = 0; i < Z_NUM; i++)
        if(zombies[i].hp && zombies[i].row == r && zombies[i].col == c)
            return 1;
    return 0;
}

static unsigned char get_zombie_char(unsigned char r, unsigned char c)
{
    unsigned char i;
    for(i = 0; i < Z_NUM; i++)
        if(zombies[i].hp && zombies[i].row == r && zombies[i].col == c)
            return (zombies[i].type == 2) ? 'j' : 'q';
    return 0;
}

static unsigned char has_bullet(unsigned char r, unsigned char c)
{
    unsigned char i;
    for(i = 0; i < B_NUM; i++)
        if(bullets[i].active && bullets[i].row == r && bullets[i].col == c)
            return 1;
    return 0;
}

static void draw_map(void)
{
    unsigned char r, c;
    unsigned char ch;
    
    for(r = 0; r < ROWS; r++)
    {
        for(c = 0; c < COLS; c++)
        {
            if(has_bullet(r, c))
                ch = '*';
            else
            {
                ch = get_zombie_char(r, c);
                if(ch == 0)
                {
                    if(map[r][c] == SUN) ch = 'S';
                    else if(map[r][c] == NUT) ch = 'N';
                    else if(map[r][c] == SHOOT) ch = 'F';
                    else if(r == cur_r && c == cur_c) ch = '|';
                    else ch = ' ';
                }
            }
            lcd_show_char(MAP_ROW + r, c, ch);
        }
        lcd_refresh_row(MAP_ROW + r);
    }
}

static void plant(unsigned char type, unsigned char cost, unsigned char init_hp)
{
    if(is_pause) return;
    if(sun < cost) return;
    if(map[cur_r][cur_c] != 0) return;
    if(has_zombie(cur_r, cur_c)) return;
    
    map[cur_r][cur_c] = type;
    hp[cur_r][cur_c] = init_hp;
    sun -= cost;
    cur_c++;
    if(cur_c >= COLS) cur_c = 0;
}

static void sun_produce(void)
{
    unsigned char r, c;
    for(r = 0; r < ROWS; r++)
        for(c = 0; c < COLS; c++)
            if(map[r][c] == SUN && hp[r][c] > 0 && sun < 250)
                sun += 5;
}

static signed char find_empty_zombie(void)
{
    unsigned char i;
    for(i = 0; i < Z_NUM; i++)
        if(zombies[i].hp == 0)
            return i;
    return -1;
}

static void create_zombie(void)
{
    signed char idx;
    unsigned char z_hp, type, r, try;
    
    if(wave == 0) return;
    idx = find_empty_zombie();
    if(idx < 0) return;
    
    if((wave >> 2) > 0)
    {
        type = 1;
        z_hp = is_hard ? Z1_HP_H : Z1_HP_E;
    }
    else if((wave & 3) > 0)
    {
        type = 2;
        z_hp = is_hard ? Z2_HP_H : Z2_HP_E;
    }
    else return;
    
    for(try = 0; try < 6; try++)
    {
        r = random_row();
        if(map[r][COLS-1] != 0 || has_zombie(r, COLS-1)) continue;
        
        zombies[idx].row = r;
        zombies[idx].col = COLS - 1;
        zombies[idx].hp = z_hp;
        zombies[idx].type = type;
        
        if(type == 1) wave -= 4;
        else wave--;
        return;
    }
}

static void zombie_hurt(unsigned char i, unsigned char dmg)
{
    if(zombies[i].hp > dmg)
        zombies[i].hp -= dmg;
    else
        zombies[i].hp = 0;
}

static void move_zombies(void)
{
    unsigned char i, nr, nc;
    
    for(i = 0; i < Z_NUM; i++)
    {
        if(zombies[i].hp == 0) continue;
        if(zombies[i].col == 0)
        {
            is_fail = 1;
            return;
        }
        
        nr = zombies[i].row;
        nc = zombies[i].col - 1;
        
        if(map[nr][nc] != 0 && hp[nr][nc] > 0)
        {
            if(hp[nr][nc] > 10) hp[nr][nc] -= 10;
            else hp[nr][nc] = 0;
            
            zombie_hurt(i, 8);
            
            if(hp[nr][nc] == 0) map[nr][nc] = 0;
            continue;
        }
        
        if(has_zombie(nr, nc)) continue;
        zombies[i].col = nc;
    }
}

static signed char find_empty_bullet(void)
{
    unsigned char i;
    for(i = 0; i < B_NUM; i++)
        if(bullets[i].active == 0)
            return i;
    return -1;
}

static unsigned char bullet_hit(unsigned char i, unsigned char r, unsigned char c)
{
    unsigned char zi;
    for(zi = 0; zi < Z_NUM; zi++)
        if(zombies[zi].hp && zombies[zi].row == r && zombies[zi].col == c)
        {
            zombie_hurt(zi, 15);
            bullets[i].active = 0;
            return 1;
        }
    return 0;
}

static void shoot(void)
{
    unsigned char r, c, nc;
    signed char idx;
    
    for(r = 0; r < ROWS; r++)
    {
        for(c = 0; c < COLS; c++)
        {
            if(map[r][c] != SHOOT || hp[r][c] == 0) continue;
            if(c >= COLS - 1) continue;
            
            nc = c + 1;
            if(map[r][nc] != 0) continue;
            
            idx = find_empty_bullet();
            if(idx < 0) continue;
            
            bullets[idx].active = 1;
            bullets[idx].row = r;
            bullets[idx].col = nc;
            bullet_hit(idx, r, nc);
        }
    }
}

static void move_bullets(void)
{
    unsigned char i, r, c;
    
    for(i = 0; i < B_NUM; i++)
    {
        if(bullets[i].active == 0) continue;
        
        r = bullets[i].row;
        c = bullets[i].col;
        
        if(bullet_hit(i, r, c)) continue;
        
        if(c >= COLS - 1)
        {
            bullets[i].active = 0;
            continue;
        }
        
        bullets[i].col++;
        bullet_hit(i, r, bullets[i].col);
    }
}

static unsigned char all_zombies_dead(void)
{
    unsigned char i;
    for(i = 0; i < Z_NUM; i++)
        if(zombies[i].hp) return 0;
    return 1;
}

static void show_result(unsigned char win)
{
    text_init();
    if(win)
    {
        lcd_show_string(0, 0, "   YOU WIN!     ");
        lcd_show_string(1, 0, "  all cleared   ");
    }
    else
    {
        lcd_show_string(0, 0, "  GAME  OVER    ");
        lcd_show_string(1, 0, " zombies home   ");
    }
    lcd_show_string(2, 0, " K4=ack wait    ");
    lcd_show_string(3, 0, "                ");
    
    while(1)
    {
        keys_scan();
        if(key_pause()) break;
        delay(50);
    }
}

void game_start(unsigned char hard)
{
    unsigned int spawn_time;
    unsigned int t;
    
    is_hard = (hard != 0);
    keys_clear();
    game_reset();
    spawn_time = is_hard ? 2000 : 2800;
    
    text_init();
    draw_top();
    draw_map();
    
    while(1)
    {
        keys_scan();
        
        if(key_pause()) is_pause = !is_pause;
        
        if(!is_pause)
        {
            if(key_down())  cur_r = (cur_r + 1) % ROWS;
            if(key_right()) cur_c = (cur_c + 1) % COLS;
            if(key_sun())   plant(SUN, 10, 20);
            if(key_nut())   plant(NUT, 20, 60);
            if(key_shoot()) plant(SHOOT, 25, 40);
            
            t = game_time;
            
            if((t - last_sun) >= 1000) { last_sun = t; sun_produce(); }
            if((t - last_spawn) >= spawn_time) { last_spawn = t; create_zombie(); }
            if((t - last_move) >= 1000) 
            { 
                last_move = t; 
                move_zombies(); 
                if(is_fail) { show_result(0); break; }
            }
            if((t - last_bul) >= 280) { last_bul = t; shoot(); move_bullets(); }
            
            if(wave == 0 && all_zombies_dead()) { show_result(1); break; }
        }
        
        draw_top();
        draw_map();
        delay(5);
    }
}