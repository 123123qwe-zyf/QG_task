#include <reg52.h>
#include <intrins.h>
#include "st7920.h"

void delay_ms(unsigned int ms)
{
    unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 120; j++);
}

void delay_us(unsigned int us)
{
    while(us--) _nop_();
}

void LCD_write_cmd(unsigned char cmd)
{
    bit ea_save = EA;
    EA = 0;
    LCD_RS = 0;
    LCD_RW = 0;
    P1 = cmd;
    LCD_E = 1;
    delay_us(10);
    LCD_E = 0;
    delay_us(200);
    EA = ea_save;
}

void LCD_write_dat(unsigned char dat)
{
    bit ea_save = EA;
    EA = 0;
    LCD_RS = 1;
    LCD_RW = 0;
    P1 = dat;
    LCD_E = 1;
    delay_us(10);
    LCD_E = 0;
    delay_us(200);
    EA = ea_save;
}

void LCD_init(void)
{
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_E  = 0;
    P1 = 0x00;
    
    LCD_RST = 0;
    delay_ms(100);
    LCD_RST = 1;
    delay_ms(100);
    
    LCD_write_cmd(0x30);  delay_ms(20);
    LCD_write_cmd(0x30);  delay_ms(10);
    LCD_write_cmd(0x30);  delay_ms(10);
    LCD_write_cmd(0x0C);  delay_ms(10);
    LCD_write_cmd(0x01);  delay_ms(30);
    LCD_write_cmd(0x06);  delay_ms(10);
}

void LCD_clear(void)
{
    LCD_write_cmd(0x01);
    delay_ms(30);
}






