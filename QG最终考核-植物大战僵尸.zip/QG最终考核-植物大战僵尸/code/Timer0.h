#ifndef TIMER0_H 
#define TIMER0_H 

#include <reg52.h>

void Timer0Init(void); 
extern volatile unsigned int idata game_time;

#endif 
