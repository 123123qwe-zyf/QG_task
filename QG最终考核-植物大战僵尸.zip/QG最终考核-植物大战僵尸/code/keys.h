#ifndef KEYS_H
#define KEYS_H

void keys_init(void);
void keys_scan(void);
unsigned char key_confirm(void);
unsigned char key_down(void);
unsigned char key_right(void);
unsigned char key_pause(void);
unsigned char key_nut(void);
unsigned char key_sun(void);
unsigned char key_shoot(void);
void keys_clear(void);

#define key_back key_pause

#endif