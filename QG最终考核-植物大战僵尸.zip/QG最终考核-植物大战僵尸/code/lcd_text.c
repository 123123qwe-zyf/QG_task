#include "st7920.h"
#include "lcd_text.h"

static unsigned char idata buffer[LCD_ROWS][LCD_COLS];

static unsigned char row_addr(unsigned char row)
{
    if(row == 0) return 0x80;
    if(row == 1) return 0x90;
    if(row == 2) return 0x88;
    if(row == 3) return 0x98;
    return 0x80;
}

void lcd_refresh_row(unsigned char row)
{
    unsigned char i;
    unsigned char addr;
    
    if(row >= LCD_ROWS) return;
    
    addr = row_addr(row);
    LCD_write_cmd(addr);
    for(i = 0; i < LCD_COLS; i++)
        LCD_write_dat(buffer[row][i]);
}

void text_init(void)
{
    unsigned char r, c;
    for(r = 0; r < LCD_ROWS; r++)
        for(c = 0; c < LCD_COLS; c++)
            buffer[r][c] = ' ';
    
    for(r = 0; r < LCD_ROWS; r++)
        lcd_refresh_row(r);
}

void lcd_show_char(unsigned char row, unsigned char col, unsigned char ch)
{
    if(row >= LCD_ROWS || col >= LCD_COLS) return;
    buffer[row][col] = ch;
}

void lcd_show_string(unsigned char row, unsigned char col, unsigned char code *s)
{
    unsigned char p = col;
    if(row >= LCD_ROWS) return;
    
    while(*s != '\0' && p < LCD_COLS)
        buffer[row][p++] = *s++;
    
    lcd_refresh_row(row);
}

void lcd_show_number(unsigned char row, unsigned char col, unsigned char num)
{
    unsigned char hi, lo;
    if(row >= LCD_ROWS || col >= LCD_COLS - 1) return;
    if(num > 99) num = 99;
    
    hi = num / 10;
    lo = num % 10;
    buffer[row][col] = '0' + hi;
    buffer[row][col + 1] = '0' + lo;
    lcd_refresh_row(row);
}