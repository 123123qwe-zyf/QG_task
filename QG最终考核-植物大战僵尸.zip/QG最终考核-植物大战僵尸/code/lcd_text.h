#ifndef LCD_TEXT_H
#define LCD_TEXT_H

#include <reg52.h>

#define LCD_ROWS  4
#define LCD_COLS  16

void text_init(void);
void lcd_show_char(unsigned char row, unsigned char col, unsigned char ch);
void lcd_show_string(unsigned char row, unsigned char col, unsigned char code *s);
void lcd_show_number(unsigned char row, unsigned char col, unsigned char num);
void lcd_refresh_row(unsigned char row);

#endif