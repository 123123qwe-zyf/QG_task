#include <reg52.h>
#include "st7920.h"
#include "lcd_text.h"
#include "Delay.h"
#include "keys.h"
#include "timer0.h"
#include "game.h"

static void reset_lcd(void)
{
    LCD_write_cmd(0x34); delay_ms(5);
    LCD_write_cmd(0x30); delay_ms(5);
    LCD_write_cmd(0x0C); delay_ms(5);
    LCD_write_cmd(0x06); delay_ms(5);
}

static void page_welcome(void)
{
    text_init();
    lcd_show_string(0, 0, "  Welcome to   ");
    lcd_show_string(1, 0, "plant vs zombie");
    lcd_show_string(2, 0, "                ");
    lcd_show_string(3, 0, "K1=OK ");
    delay(2000);
}

static void page_menu(unsigned char sel)
{
    text_init();
    lcd_show_char(0, 0, sel == 0 ? '>' : ' ');
    lcd_show_string(0, 1, "How To Play    ");
    lcd_show_char(1, 0, sel == 1 ? '>' : ' ');
    lcd_show_string(1, 1, " PLAY           ");
    lcd_show_string(2, 0, "                ");
    lcd_show_string(3, 0, "K2=sel  K1=enter");
}

static void page_help(void)
{
    text_init();
    lcd_show_string(0, 0, " use buttons to ");
    lcd_show_string(1, 0, " move & plant  ");
    lcd_show_string(2, 0, " defeat zombies ");
    lcd_show_string(3, 0, " KEY4 = BACK     ");
}

static void page_level(unsigned char sel)
{
    text_init();
    lcd_show_char(0, 0, sel == 0 ? '>' : ' ');
    lcd_show_string(0, 1, "LEVEL 1 EASY    ");
    lcd_show_char(1, 0, sel == 1 ? '>' : ' ');
    lcd_show_string(1, 1, "LEVEL 2 HARD    ");
    lcd_show_string(2, 0, "                ");
    lcd_show_string(3, 0, "K1=start game   ");
}

void app_run(void)
{
    unsigned char sel, moved;
    
    LCD_init();
    reset_lcd();
    text_init();
    keys_init();
    
    page_welcome();
    
    sel = 0;
    page_menu(sel);
    
    while(1)
    {
        moved = 0;
        keys_scan();
        
        if(key_down()) { sel ^= 1; moved = 1; }
        if(key_confirm())
        {
            if(sel == 0)
            {
                page_help();
                while(1)
                {
                    keys_scan();
                    if(key_back()) break;
                    delay(10);
                }
                page_menu(sel);
            }
            else break;
        }
        if(moved) page_menu(sel);
        delay(10);
    }
    
    sel = 0;
    page_level(sel);
    while(1)
    {
        moved = 0;
        keys_scan();
        
        if(key_down()) { sel ^= 1; moved = 1; }
        if(key_confirm()) break;
        if(moved) page_level(sel);
        delay(10);
    }
    
    Timer0Init();
    EA = 1;
    
    game_start(sel);
}